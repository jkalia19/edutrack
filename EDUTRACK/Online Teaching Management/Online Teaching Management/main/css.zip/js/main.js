include('js/html5.js');
//----jquery-plagins----
include('js/jquery-1.6.1.min.js');
include('js/jquery.easing.1.3.js');
include('js/jquery.color.js');
//----transform----
include('js/jquery.transform.js');
//----ContentSwitcher----
include('js/switcher.js');
//----google map----
include('js/googleMap.js');
//----contact form----
include('js/cform.js');
//----jScrollPane-----
include('js/jquery.mousewheel.js');
include('js/mwheelIntent.js');
include('js/jquery.jscrollpane.min.js');
//----Lightbox--
include('js/jquery.prettyPhoto.js');
//----jplayer-sound--
include('js/jquery.jplayer.min.js');
//----All-Scripts----
include('js/script.js');
//----Include-Function----
function include(url){ 
  document.write('<script type="text/javascript" src="'+ url +'" ></script>'); 
}