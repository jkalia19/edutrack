﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace final_project.main
{
    public partial class WebForm6 : System.Web.UI.Page
    {
        SqlConnection con;
        SqlCommand cmd;
        SqlDataReader dr;

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btn1_Click(object sender, EventArgs e)
        {
            con = new SqlConnection();
            con.ConnectionString = ConfigurationManager.ConnectionStrings["cn"].ConnectionString;
            con.Open();
            cmd = new SqlCommand("select regno,password from St_add where regno=@regno and password=@password", con);
            cmd.Parameters.Add("@regno", SqlDbType.NVarChar, 20).Value = Txt_reg.Text;
            cmd.Parameters.Add("@password", SqlDbType.NVarChar, 32).Value = Txt_password.Text;
            dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                Session["regNo"] = Txt_reg.Text;
                Response.Redirect("~/user/home.aspx");
            }
            
           
                cmd.Dispose();
                dr.Close();
                cmd = new SqlCommand("select ecode,password from Emp_add where ecode=@ecode and password=@password", con);
                cmd.Parameters.Add("@ecode", SqlDbType.NVarChar, 20).Value = Txt_reg.Text;
                cmd.Parameters.Add("@password", SqlDbType.NVarChar, 32).Value = Txt_password.Text;
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    Session["ad"] = Txt_reg.Text;
                    Response.Redirect("~/ADMIN/Welocme.aspx");
                }
                else
                { 
          //  Response.Write("  <script type=text/javascript>alert(user name is wrong)</script>");
                    lb2.Text = "Invalid Username or Password";
                }
            
            


        }
    }
}