﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace final_project.main
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        SqlConnection con;
        SqlCommand cmd;
        SqlDataReader dr;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Lbt_login_Click(object sender, EventArgs e)
        {
            con = new SqlConnection();
            con.ConnectionString = ConfigurationManager.ConnectionStrings["cn"].ConnectionString;
            con.Open();
            cmd = new SqlCommand("select regno,password from St_add where regno=@regno and password=@password",con);
            cmd.Parameters.Add("@regno", SqlDbType.NVarChar, 20).Value = Txt_regno.Text;
            cmd.Parameters.Add("@password", SqlDbType.NVarChar, 32).Value = Txt_Password.Text;
            dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
               Response.Redirect("~/user/home.aspx?x="+Txt_regno.Text);
            }
        }
    }
}